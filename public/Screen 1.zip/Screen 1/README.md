# Screen 1

This is a code bundle for Screen 1. It's based on default Vite project. The original design is available at https://app.flowstep.ai/file?activeFileId=756191d0-ab45-49aa-a97b-44539590bb17.

## Running the code

Run `npm i` and `npm run setup` to install the dependencies.

Run `npm run dev` to start the development server.
