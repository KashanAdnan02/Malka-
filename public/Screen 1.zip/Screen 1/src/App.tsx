import { useEffect } from "react";
import {
  ArrowRight,
  BadgeCheck,
  CalendarHeart,
  Gem,
  Home,
  Info,
  LayoutGrid,
  Mail,
  RefreshCw,
  Scale,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Sparkles,
  Star,
  Truck,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

import { FallbackComponent } from "./CustomComponents";

export default function App() {
  return (
    <div>
      <div className="bg-white text-neutral-950 w-full h-fit h-fit min-h-screen w-screen min-w-screen max-w-screen overflow-visible">
        <header className="bg-white border-neutral-200 border-t-0 border-r-0 border-b-1 border-l-0 border-solid w-full">
          <div className="max-w-[1140px] flex mx-auto px-12 justify-between items-center h-20">
            <div className="flex items-center gap-2">
              <div className="size-9 rounded-full bg-neutral-900 flex justify-center items-center">
                <Gem className="size-5 text-neutral-50" />
              </div>
              <div className="leading-none flex flex-col">
                <span className="font-semibold text-lg leading-7 tracking-tight">
                  Malka Jewellers
                </span>
                <span className="uppercase text-neutral-500 text-[11px] tracking-widest">
                  Fine Gold Jewellery
                </span>
              </div>
            </div>
            <nav className="flex items-center gap-8">
              <a className="font-medium text-neutral-950 text-sm leading-5 border-neutral-900 border-t-0 border-r-0 border-b-2 border-l-0 border-solid flex pb-1 items-center gap-2">
                <Home className="size-4" />
                Home
              </a>
              <a className="border-transparent font-medium text-neutral-500 text-sm leading-5 border-black/1 border-t-0 border-r-0 border-b-2 border-l-0 border-solid flex pb-1 items-center gap-2">
                <ShoppingBag className="size-4" />
                Shop
              </a>
              <a className="border-transparent font-medium text-neutral-500 text-sm leading-5 border-black/1 border-t-0 border-r-0 border-b-2 border-l-0 border-solid flex pb-1 items-center gap-2">
                <Info className="size-4" />
                About
              </a>
              <a className="border-transparent font-medium text-neutral-500 text-sm leading-5 border-black/1 border-t-0 border-r-0 border-b-2 border-l-0 border-solid flex pb-1 items-center gap-2">
                <Mail className="size-4" />
                Contact
              </a>
            </nav>
            <div className="flex items-center gap-3">
              <Button
                className="relative border-neutral-200 border-0 border-solid"
                size="icon"
                variant="outline"
              >
                <ShoppingCart className="size-4" />
                <span className="size-4 bg-[oklch(0.769_0.188_70.08)] rounded-full text-neutral-50 text-[10px] flex absolute -right-1 -top-1 justify-center items-center">
                  2
                </span>
              </Button>
              <Button className="bg-neutral-900 text-neutral-50">
                <ShoppingBag className="size-4 mr-2" />
                Shop Now
              </Button>
            </div>
          </div>
        </header>
        <main className="max-w-[1140px] flex mx-auto p-12 flex-col gap-12">
          <section className="grid grid-cols-2 items-center gap-8">
            <div className="flex flex-col gap-6">
              <Badge className="bg-neutral-100 text-neutral-900 border-neutral-200 border-1 border-solid w-fit">
                <BadgeCheck className="size-3.5 text-[oklch(0.769_0.188_70.08)] mr-1" />
                {`Certified 916 & 750 Hallmark Gold`}
              </Badge>
              <h1 className="font-semibold text-5xl leading-[53px] tracking-tight">
                Timeless Gold Jewellery for Every Occasion
              </h1>
              <p className="leading-relaxed text-neutral-500 text-base leading-6">
                Discover handcrafted gold rings, earrings, necklaces and bangles
                made to celebrate your moments. Transparent weight, carat and
                pricing on every piece — designed to be treasured for a
                lifetime.
              </p>
              <div className="flex items-center gap-4">
                <Button className="bg-neutral-900 text-neutral-50 px-6 h-11">
                  <Sparkles className="size-4 mr-2" />
                  Shop Collection
                </Button>
                <Button
                  className="border-neutral-200 border-0 border-solid px-6 h-11"
                  variant="outline"
                >
                  <LayoutGrid className="size-4 mr-2" />
                  Explore Designs
                </Button>
              </div>
              <div className="flex pt-2 items-center gap-8">
                <div className="flex flex-col">
                  <span className="font-semibold text-2xl leading-8">
                    50,000+
                  </span>
                  <span className="text-neutral-500 text-xs leading-4">
                    Happy Customers
                  </span>
                </div>
                <div className="bg-neutral-200 w-px h-10" />
                <div className="flex flex-col">
                  <span className="font-semibold text-2xl leading-8">100%</span>
                  <span className="text-neutral-500 text-xs leading-4">
                    Certified Purity
                  </span>
                </div>
                <div className="bg-neutral-200 w-px h-10" />
                <div className="flex flex-col">
                  <span className="font-semibold text-2xl leading-8">Free</span>
                  <span className="text-neutral-500 text-xs leading-4">
                    Insured Delivery
                  </span>
                </div>
              </div>
            </div>
            <div className="relative rounded-3xl border-neutral-200 border-1 border-solid h-110 overflow-hidden">
              <img
                alt="Luxury gold jewellery"
                className="object-cover w-full h-full"
                data-authorname="Segal Jewelry"
                data-authorurl="https://unsplash.com/@segaljewelry"
                data-blurhash="LTN0Vd-;yYs:E1-;XTxu0KxvMws:"
                data-photoid="NsH-CvU0deg"
                src="https://images.unsplash.com/photo-1633934542430-0905ccb5f050?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBnb2xkJTIwamV3ZWxsZXJ5JTIwZWxlZ2FudHxlbnwxfDB8fHwxNzgwMjExODUyfDA&ixlib=rb-4.1.0&q=80&w=1200"
              />
              <div className="bg-gradient-to-t from-foreground/60 to-transparent absolute inset-0" />
              <div className="rounded-2xl bg-white border-neutral-200 border-1 border-solid flex absolute inset-x-6 bottom-6 p-4 justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="size-10 bg-[oklch(0.769_0.188_70.08)]/15 rounded-full flex justify-center items-center">
                    <ShieldCheck className="size-5 text-[oklch(0.769_0.188_70.08)]" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-neutral-500 text-xs leading-4">
                      BIS Hallmark Assured
                    </span>
                    <span className="font-semibold text-sm leading-5">
                      Guaranteed 22K Purity
                    </span>
                  </div>
                </div>
                <Badge className="bg-[oklch(0.769_0.188_70.08)]/15 text-[oklch(0.646_0.16_70)]">
                  <Star className="size-3 mr-1" />
                  4.9
                </Badge>
              </div>
            </div>
          </section>
          <section className="flex flex-col gap-8">
            <div className="flex justify-between items-end">
              <div className="flex flex-col gap-2">
                <span className="font-medium uppercase text-neutral-500 text-sm leading-5 tracking-widest">
                  Our Collection
                </span>
                <h2 className="font-semibold text-3xl leading-9 tracking-tight">
                  Featured Gold Pieces
                </h2>
              </div>
              <Button className="text-sm leading-5" variant="ghost">
                View all
                <ArrowRight className="size-4 ml-1" />
              </Button>
            </div>
            <div className="grid grid-cols-4 gap-6">
              <Card className="border-neutral-200 border-1 border-solid p-0 gap-0 overflow-hidden">
                <div className="relative w-full h-48 overflow-hidden">
                  <img
                    alt="Gold ring"
                    className="object-cover w-full h-full"
                    data-authorname="Sabrianna"
                    data-authorurl="https://unsplash.com/@sabrinnaringquist"
                    data-blurhash="LDPj7Bog?dxt?bj]WBWAx_axMwa~"
                    data-photoid="NhrcL_C0sFA"
                    src="https://images.unsplash.com/photo-1598560917807-1bae44bd2be8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxnb2xkJTIwcmluZyUyMGRpYW1vbmR8ZW58MXwyfHx8MTc4MDIxMTg1Mnww&ixlib=rb-4.1.0&q=80&w=600"
                  />
                  <Badge className="bg-neutral-900 text-neutral-50 absolute left-3 top-3">
                    22K
                  </Badge>
                </div>
                <CardContent className="flex p-4 flex-col gap-3">
                  <div className="flex flex-col gap-0.5">
                    <span className="font-semibold text-sm leading-5">
                      Aurelia Solitaire Ring
                    </span>
                    <span className="text-neutral-500 text-xs leading-4">
                      SKU: MR-1042
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-neutral-500 text-xs leading-4 flex items-center gap-1">
                      <Scale className="size-3.5" />
                      4.2 g
                    </span>
                    <span className="text-neutral-500 text-xs leading-4 flex items-center gap-1">
                      <Gem className="size-3.5" />
                      22 Carat
                    </span>
                  </div>
                  <div className="border-neutral-200 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex mt-1 pt-3 justify-between items-center">
                    <span className="font-semibold text-neutral-950 text-base leading-6">
                      $329
                    </span>
                    <Button
                      className="bg-neutral-900 text-neutral-50 h-8"
                      size="sm"
                    >
                      <ShoppingCart className="size-3.5 mr-1" />
                      Add
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-neutral-200 border-1 border-solid p-0 gap-0 overflow-hidden">
                <div className="relative w-full h-48 overflow-hidden">
                  <img
                    alt="Gold earrings"
                    className="object-cover w-full h-full"
                    data-authorname="NEXARO STUDIO"
                    data-authorurl="https://unsplash.com/@nexarostudio"
                    data-blurhash="L24os3Mx4U_Mr?o}bva04Vxa?FD*"
                    data-photoid="u1Wmh35Oms4"
                    src="https://images.unsplash.com/photo-1722410180651-efd51636f260?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxnb2xkJTIwZWFycmluZ3MlMjBsdXh1cnl8ZW58MXwyfHx8MTc4MDIxMTg1M3ww&ixlib=rb-4.1.0&q=80&w=600"
                  />
                  <Badge className="bg-neutral-900 text-neutral-50 absolute left-3 top-3">
                    18K
                  </Badge>
                </div>
                <CardContent className="flex p-4 flex-col gap-3">
                  <div className="flex flex-col gap-0.5">
                    <span className="font-semibold text-sm leading-5">
                      Lumière Drop Earrings
                    </span>
                    <span className="text-neutral-500 text-xs leading-4">
                      SKU: ME-2087
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-neutral-500 text-xs leading-4 flex items-center gap-1">
                      <Scale className="size-3.5" />
                      6.8 g
                    </span>
                    <span className="text-neutral-500 text-xs leading-4 flex items-center gap-1">
                      <Gem className="size-3.5" />
                      18 Carat
                    </span>
                  </div>
                  <div className="border-neutral-200 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex mt-1 pt-3 justify-between items-center">
                    <span className="font-semibold text-neutral-950 text-base leading-6">
                      $512
                    </span>
                    <Button
                      className="bg-neutral-900 text-neutral-50 h-8"
                      size="sm"
                    >
                      <ShoppingCart className="size-3.5 mr-1" />
                      Add
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-neutral-200 border-1 border-solid p-0 gap-0 overflow-hidden">
                <div className="relative w-full h-48 overflow-hidden">
                  <img
                    alt="Gold necklace"
                    className="object-cover w-full h-full"
                    data-authorname="NEXARO STUDIO"
                    data-authorurl="https://unsplash.com/@nexarostudio"
                    data-blurhash="L7HbiEoLm,nj}9fP.Qj[9bj[%Kfk"
                    data-photoid="xu_zM4np434"
                    src="https://images.unsplash.com/photo-1721103418312-b0057a8c31c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxnb2xkJTIwbmVja2xhY2UlMjBqZXdlbGxlcnl8ZW58MXwyfHx8MTc4MDE5NjI5MHww&ixlib=rb-4.1.0&q=80&w=600"
                  />
                  <Badge className="bg-neutral-900 text-neutral-50 absolute left-3 top-3">
                    22K
                  </Badge>
                </div>
                <CardContent className="flex p-4 flex-col gap-3">
                  <div className="flex flex-col gap-0.5">
                    <span className="font-semibold text-sm leading-5">
                      Regina Chain Necklace
                    </span>
                    <span className="text-neutral-500 text-xs leading-4">
                      SKU: MN-3310
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-neutral-500 text-xs leading-4 flex items-center gap-1">
                      <Scale className="size-3.5" />
                      14.5 g
                    </span>
                    <span className="text-neutral-500 text-xs leading-4 flex items-center gap-1">
                      <Gem className="size-3.5" />
                      22 Carat
                    </span>
                  </div>
                  <div className="border-neutral-200 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex mt-1 pt-3 justify-between items-center">
                    <span className="font-semibold text-neutral-950 text-base leading-6">
                      $1,136
                    </span>
                    <Button
                      className="bg-neutral-900 text-neutral-50 h-8"
                      size="sm"
                    >
                      <ShoppingCart className="size-3.5 mr-1" />
                      Add
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-neutral-200 border-1 border-solid p-0 gap-0 overflow-hidden">
                <div className="relative w-full h-48 overflow-hidden">
                  <img
                    alt="Gold bangle"
                    className="object-cover w-full h-full"
                    data-authorname="Bulbul Ahmed"
                    data-authorurl="https://unsplash.com/@bulbul252"
                    data-blurhash="LFQc3pV?yZx]MwRjtSjspLkDMcV?"
                    data-photoid="KVoWg1W2ztk"
                    src="https://images.unsplash.com/photo-1629118639934-2b241503956c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3ODc2NDd8MHwxfHNlYXJjaHwxfHxnb2xkJTIwYnJhY2VsZXQlMjBiYW5nbGUlMjBqZXdlbGxlcnl8ZW58MXwyfHx8MTc4MDIxMTg1Mnww&ixlib=rb-4.1.0&q=80&w=600"
                  />
                  <Badge className="bg-neutral-900 text-neutral-50 absolute left-3 top-3">
                    24K
                  </Badge>
                </div>
                <CardContent className="flex p-4 flex-col gap-3">
                  <div className="flex flex-col gap-0.5">
                    <span className="font-semibold text-sm leading-5">
                      Maharani Bangle Set
                    </span>
                    <span className="text-neutral-500 text-xs leading-4">
                      SKU: MB-4521
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-neutral-500 text-xs leading-4 flex items-center gap-1">
                      <Scale className="size-3.5" />
                      22.0 g
                    </span>
                    <span className="text-neutral-500 text-xs leading-4 flex items-center gap-1">
                      <Gem className="size-3.5" />
                      24 Carat
                    </span>
                  </div>
                  <div className="border-neutral-200 border-t-1 border-r-0 border-b-0 border-l-0 border-solid flex mt-1 pt-3 justify-between items-center">
                    <span className="font-semibold text-neutral-950 text-base leading-6">
                      $1,847
                    </span>
                    <Button
                      className="bg-neutral-900 text-neutral-50 h-8"
                      size="sm"
                    >
                      <ShoppingCart className="size-3.5 mr-1" />
                      Add
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>
          <section className="flex flex-col gap-8">
            <div className="text-center flex flex-col items-center gap-2">
              <span className="font-medium uppercase text-neutral-500 text-sm leading-5 tracking-widest">
                Why Shop With Us
              </span>
              <h2 className="font-semibold text-3xl leading-9 tracking-tight">
                Crafted for You, Trusted by Many
              </h2>
            </div>
            <div className="grid grid-cols-3 gap-6">
              <Card className="border-neutral-200 border-1 border-solid p-6 gap-4">
                <CardHeader className="p-0 gap-2">
                  <div className="size-11 rounded-xl bg-neutral-100 flex justify-center items-center">
                    <ShieldCheck className="size-5 text-neutral-900" />
                  </div>
                  <span className="font-semibold text-base leading-6">
                    Certified Hallmark Gold
                  </span>
                </CardHeader>
                <CardContent className="p-0">
                  <p className="leading-relaxed text-neutral-500 text-sm leading-5">
                    Every piece is BIS hallmarked with verifiable purity from
                    18K to 24K, so you always know exactly what you own.
                  </p>
                </CardContent>
              </Card>
              <Card className="border-neutral-200 border-1 border-solid p-6 gap-4">
                <CardHeader className="p-0 gap-2">
                  <div className="size-11 rounded-xl bg-neutral-100 flex justify-center items-center">
                    <RefreshCw className="size-5 text-neutral-900" />
                  </div>
                  <span className="font-semibold text-base leading-6">
                    Lifetime Exchange
                  </span>
                </CardHeader>
                <CardContent className="p-0">
                  <p className="leading-relaxed text-neutral-500 text-sm leading-5">
                    Enjoy lifetime exchange and buyback at fair gold value,
                    making your jewellery a smart, flexible investment.
                  </p>
                </CardContent>
              </Card>
              <Card className="border-neutral-200 border-1 border-solid p-6 gap-4">
                <CardHeader className="p-0 gap-2">
                  <div className="size-11 rounded-xl bg-neutral-100 flex justify-center items-center">
                    <Truck className="size-5 text-neutral-900" />
                  </div>
                  <span className="font-semibold text-base leading-6">
                    Free Insured Shipping
                  </span>
                </CardHeader>
                <CardContent className="p-0">
                  <p className="leading-relaxed text-neutral-500 text-sm leading-5">
                    Fully insured, tracked doorstep delivery with easy 15-day
                    returns and dedicated customer care every step.
                  </p>
                </CardContent>
              </Card>
            </div>
          </section>
          <section className="rounded-3xl bg-neutral-900 text-neutral-50 flex p-12 justify-between items-center">
            <div className="max-w-xl flex flex-col gap-3">
              <h2 className="font-semibold text-3xl leading-9 tracking-tight">
                Find your perfect piece today
              </h2>
              <p className="leading-relaxed text-neutral-50/80 text-sm leading-5">
                Browse our latest collections or book a personal styling
                consultation with our gold experts — online or in store.
              </p>
            </div>
            <div className="flex items-center gap-4">
              <Button className="bg-white text-neutral-950 px-6 h-11">
                <ShoppingBag className="size-4 mr-2" />
                Start Shopping
              </Button>
              <Button
                className="bg-transparent text-neutral-50 border-neutral-50/30 border-0 border-solid px-6 h-11"
                variant="outline"
              >
                <CalendarHeart className="size-4 mr-2" />
                Book a Consultation
              </Button>
            </div>
          </section>
        </main>
        <footer className="border-neutral-200 border-t-1 border-r-0 border-b-0 border-l-0 border-solid">
          <div className="max-w-[1140px] flex mx-auto px-12 py-8 justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="size-7 rounded-full bg-neutral-900 flex justify-center items-center">
                <Gem className="size-4 text-neutral-50" />
              </div>
              <span className="font-medium text-sm leading-5">
                Malka Jewellers
              </span>
            </div>
            <span className="text-neutral-500 text-xs leading-4">
              © 2025 Malka Jewellers. All rights reserved.
            </span>
            <div className="text-neutral-500 flex items-center gap-4">
              <FallbackComponent className="size-4" />
              <FallbackComponent className="size-4" />
              <FallbackComponent className="size-4" />
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
